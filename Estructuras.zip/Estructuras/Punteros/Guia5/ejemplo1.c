#include <stdio.h>
#include <stdlib.h>

void intercambiar(int *p_a,int *p_b){

	*p_a=*p_a+*p_b;
	*p_b=*p_a-*p_b;
	*p_a=*p_a-*p_b;

}

int main()
{
	/* code */
	int a=5;
	int b=10;

	intercambiar(&a,&b);

	printf("El numero de a: %d\n",a);
printf("El numero de a: %d\n",b);
	return 0;
}