#include <stdlib.h>
#include <stdio.h>

int main()
{
	/* code */
	char vector[25];
	char letra;
	char *puntero;
	int i=0;
	for ( letra = 'A'; letra <='Z'; letra++)
	{
		if (i<=25)
		{
			vector[i]=letra;
		}
		i++;
	}

	

	for (int i = 25; i >=0; i--)
	{
		puntero=&vector[i];
		printf("\n");
		printf("%c",*puntero );
		printf("\t");
		printf("%p",puntero );
		puntero++
;	}
	return 0;
}