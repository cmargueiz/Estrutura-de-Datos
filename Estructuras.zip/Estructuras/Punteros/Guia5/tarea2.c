#include <stdlib.h>
#include <stdio.h>


/*void intercambiar(char *p_vector1,char *p_vector2){
	char *aux;

	*aux=*p_vector1;
	*p_vector1=*p_vector2;
	*p_vector2=*aux;


}*/

int main()
{
	/* code */
	char vector1[25];
	char *puntero1;
	
	char vector2[25];
	char *aux;
	char *puntero2;
	char letra;
	int i=0;
	for ( letra = 'A'; letra <='Z'; letra++)
	{
		if (i<=25)
		{
			vector1[i]=letra;
		}
		i++;
	}

	
	i=0;



		for ( letra = 'Z'; letra >='A'; letra--)
	{
		if (i<=25)
		{
			vector2[i]=letra;
		}
		i++;
	}


puntero1=vector1;
puntero2=vector2;

for(i=0;i<25;i++){
aux=*puntero1;
*puntero1=*puntero2;
*puntero2=aux;
puntero1++;
puntero2++;
}


for (int i = 0; i < 25; ++i)
{
	printf("%c\n",vector1[i] );
}

printf("________________________________________\n");

for (int i = 0; i < 25; ++i)
{
	printf("%c\n",vector2[i] );
}


	return 0;
}