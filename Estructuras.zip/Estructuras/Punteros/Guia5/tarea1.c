#include <stdio.h>
#include <stdlib.h>

int main()
{
	/* code */
	int num1;
	int num2;
	int ctrl=1;
	int *p_num1;
	 int *p_num2;

int total, diferencia;
	while(ctrl!=5){
		printf("1. Ingrese dos numeros\n2. Calcular suma\n3. Calcular resta\n4. Imprimir direccion de memoria\n5. Salir");
		scanf("%d",&ctrl);

		 switch(ctrl){
		 	case 1:
		 		printf("Ingrese el primer numero: ");
		 		scanf("%d",&num1);
		 		printf("\nIngrese el segundo numero:" );
		 		scanf("%d",&num2);
		 		printf("\n");
		 		p_num1=&num1;
		 		p_num2=&num2;

		 	break;
		 	case 2:
	 		
		 		

		 		printf("%d\n",*p_num1 );
		 		printf("%d\n",*p_num2 );

		 		total= *p_num1+*p_num2;

		 		printf("La suma es: %d\n",total);
		 	break;
		 	case 3:
		 			diferencia=*p_num1-*p_num2;
		 			printf("La diferencia es: %d\n",diferencia);
		 	break;

		 	case 4:
		 		printf("%p\n", p_num1 );
		 		printf("%p\n", p_num2 );

		 	break;

		 }


	}



	return 0;
}