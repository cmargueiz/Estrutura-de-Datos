#include <stdio.h>
int main()
{
	/* code */
	long valor1=20000;
	long valor2=20000;
	long *ptrL;
	ptrL=&valor1;

	printf("%li\n",*ptrL);

	valor2=*ptrL;

	printf("%li\n",valor2 );

	printf("%li\n",&valor1 );

	printf("%p\n",&ptrL);	




	return 0;
}