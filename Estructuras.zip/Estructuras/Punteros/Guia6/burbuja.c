#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>
 
int main(){
	int *ptr,aux;
	int dim = 0;
	int *ptr_pos, *ptr_pas, *ptr_aux;
	clrscr();
	printf("Numero de posiciones: ");
	scanf("%d",&dim);
	ptr = (int *) malloc(dim * sizeof(int));
	printf("introdusca los calores: n");
	for(ptr_aux = ptr; ptr_aux < (ptr + dim); ptr_aux++){
		printf("[ %X ] = ",ptr_aux); scanf("%d",ptr_aux);
	}
	printf("Los valores introducidos son: n");
	for(ptr_aux = ptr; ptr_aux < (ptr + dim); ptr_aux++)
		printf(" %d ",*ptr_aux);
	for( ptr_pas = ptr; ptr_pas < (ptr + dim) - 1; ptr_pas++){
		for(ptr_pos = ptr; ptr_pos < (ptr + dim) - 1; ptr_pos++){
			if(*ptr_pos > *(ptr_pos + 1)){
				aux =  *ptr_pos;
				*ptr_pos = *(ptr_pos + 1);
				*(ptr_pos +1) = aux;
			}
		}
	}
	printf("nLos valores ordenados son: n");
	for(ptr_aux = ptr; ptr_aux < (ptr + dim) - 1; ptr_aux++)
		printf(" %d ",*ptr_aux);
	getch();
	for(int x = 0; x < dim; x++)
		free(ptr++);
	return 0;
}