#include <stdio.h>

void burbuja(int *vector,int tamano){

	int aux;

	for (int i = 0; i < tamano; i++)
	{
		for (int i = 0; i < tamano-1; i++)
		{
			if (*vector[i]>*vector[i+1])
			{
				aux=*vector[i];
				*vector[i]=*vector[i+1];
				*vector[i+1]=aux;
			}
		}
	}


	for (int i = 0; i < tamano; ++i)
	{
		printf("%d\n",*vector );
		vector++;
	}




}

int main()
{
	
	int tamano;
	printf("Ingrese el tamano del vector\n");
	scanf("%d",&tamano);

	int vector[tamano];

	printf("Ingrese datos al vector\n")

	for (int i = 0; i < tamano; i++)
	{
		scanf("%d",&vector[i]);
	}

	for (int i = 0; i < tamano; i++)
	{
		printf("%d\n",vector[i]);

	}
	printf("___________________________________________\n");

	burbuja(&vector,tamano);

	return 0;
}