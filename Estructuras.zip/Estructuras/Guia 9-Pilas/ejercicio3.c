#include<stdio.h>
int MAXSIZE= 8;
int pila[8];
int top=-1;

void cambiar();
int isEmpty();
int isFull();
int cuenta();
int pop();
int push();
int nuevo,viejo;

int isEmpty(){
  if (top == -1)
  return 1;
  else 
  return 0;
}

int isFull(){
  if (top==MAXSIZE)
  return 1;
  else 
  return 0;
}	

int cuenta(){
	return pila[top];
	}
	
		
int pop(){
	int datos;
	if (!isEmpty())
	{    
		
		int cm=pila[top];
		if (cm==viejo)
		{
			pila[top]=nuevo;
		}
		
		datos=pila[top];
		top=top-1;
		return datos;
	}else{
		printf("\tLa pila esta vacia\n");
		}
	}


	
	int push(int datos){
		if (!isFull())
		{
			top=top+1;
			pila[top]=datos;
		}else{
			printf("\tLa pila esta llena\n");
			}
		}	



	int main(){
	//ingresamos datos
	push(8);
	push(3);
	push(6);
	push(5);
	push(9);
	push(1);
	push(12);
	push(15);	

	printf("\nIngrese el dato nuevo:\n");
	scanf("%d",&nuevo);
	printf("\nInrese el dato viejo:\n");
	scanf("%d",&viejo);
	printf("\n\tNumero de elementos de la pila :%d\n",cuenta());
	printf("Elementos: \n");
	//Imprimimos los elementos en el orden ingresados
	
	while (!isEmpty())
	{
   int datos=pop();
   printf("%d\n",datos);		
	}
      printf("\nPila llena: %s\n" , isFull()?"true":"false");
	  printf("Pila vacia: %s\n" , isEmpty()?"true":"false");

		}