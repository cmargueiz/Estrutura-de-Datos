#include <stdio.h>

int MAXSIZE=8;
int pila[8];
int top=-1;

int isEmpty();
int isFull();
int count();
int pop();
void push();

int isEmpty(){
	if (top==-1)
	{
		return 1;
	}else{
		return 0;
	}
}

int isFull(){
	if (top==MAXSIZE)
	{
		return 1;
	}else{
		return 0;
	}
}

int count(){
	return pila[top];
}

int pop(){
	int datos;
	if (!isEmpty())
	{
		datos=pila[top];
		top=top-1;
		return datos;
	}else{
		printf("\nLa pila esta vacia\n");
	}
}

void push(int datos){
	if (!isFull())
	{
		top++;
		pila[top]=datos;
	}else{
		printf("\nLa pila esta llena\n");
	}
}

int main()
{
	/* code */

	push(1);
	push(2);
	push(3);
	push(4);
	push(5);
	push(6);
	push(7);
	push(8);

		printf("Pila llena: %s\n",isFull()?"true":"false");
	printf("Pila vacia: %s\n",isEmpty()?"true":"false");

	printf("\nElementos dentro de la pila: %d\n",count());

	printf("Elementos\n");

	while(!isEmpty()){
		int datos=pop();
		printf("%d\n", datos);
	}

	printf("Pila llena: %s\n",isFull()?"true":"false");
	printf("Pila vacia: %s\n",isEmpty()?"true":"false");
	return 0;
}