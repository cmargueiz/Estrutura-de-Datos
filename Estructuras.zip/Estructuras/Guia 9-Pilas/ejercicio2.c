#include<stdio.h>


int MAXSIZE= 8;
int pila[8];
int top=-1;
int *pil=pila;
int auxCambio[8];

void cambiar();
int isEmpty();
int isFull();
int cuenta();
int pop();
int push();

//Funcion para ver si la pila esta LLENA
int isFull(){
  if (top==MAXSIZE)
  return 1;
  else 
  return 0;
}	

//Funcion para ver si la pila esta vacia
int isEmpty(){
  if (top == -1)
  return 1;
  else 
  return 0;
}



int cuenta(){
	return pila[top];
	}
	
//Invierte los numeros de la pila procesada
void cambiar(){
	
	if (!isEmpty())
	{   
		int i;
	    int j=0;
		 for (i = (MAXSIZE-1) ; i >=0  ; i--)
	  {   
		int cam =pil[i];
		auxCambio[j]= cam;
		
	}
	     
	  }
	}
	
	
		
int pop(){
	int datos;
	if (!isEmpty())
	{    
		
		datos=pila[top];
		auxCambio[top]=datos;
		top=top-1;
		return datos;
	}else{
		printf("\tLa pila esta vacia\n");
		}
	}


	
	int push(int datos){
		if (!isFull()){
			top=top+1;
			pila[top]=datos;
		}else{
			printf("\tLa pila esta llena\n");
			
	}}	



	int main(){
	//Ingresar datos a la pila
	push(7);
	push(8);
	push(9);
	push(1);
	push(11);
	push(12);	
	printf("\tElementos dentro la pila :%d\n",cuenta());
	printf("cambiar elementos: \n");
	//Se imprime la pila segun se han ingresado
	
	while (!isEmpty()){
   int datos=pop();
   printf("%d\n",datos);		
	}
	//Pila invertida
	  printf("\nelementos invertidos :\n");
	  
	 int i;
	   
	 for (i = 0 ; i < MAXSIZE  ; i++)
	  {   
		  if (auxCambio[i]==0)
		  {
			break;
		  }else{
		  
		printf("\n%d",auxCambio[i]);
		 }
		}
		return 0;
	}