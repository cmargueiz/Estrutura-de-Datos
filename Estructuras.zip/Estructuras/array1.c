#include <stdio.h>
void main(void){
	/* code */
	int datos[50],i,n,suma=0;

	printf("Suma de los elementos de un vector\n" );
	printf("---------------------------------\n" );
	printf("Ingrese la cantidad de elementosque desea sumar\n");
	scanf("%d",&n);

	//se llena el array

	for (int i = 0; i < n; i++)
	{
		/* code */
		printf("Numero - %d",+1 );
		scanf("%d",&datos[i]);
	}

	//se suman todos los elementos
	for (int i = 0; i < n; i++)
	{
		/* code */
		suma+=datos[i];

	}

	printf("La suma de todos los elementos dentro del array es de: %d\n",suma );
}