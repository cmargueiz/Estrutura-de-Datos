#include<stdio.h>
int main(void){
		int num,acum,i;
		
		acum=0;
		printf("Ingrese un numero");
		
		scanf("%d",&num);
		for (i = 0; i < num; i++)
		{
			if (num%i==0)
			{
				acum=acum+i;
			}
			
		}
		if (num==acum)
		{
			printf("Es perfecto el numero %d",num);
		}else{
			printf("No es perfecto el numero: %d",num);
			}
		
		
		
		
		
	}
