#include <stdio.h>
int tamano;
int main(void)
{
	/* code */
	//Array al reves
	//Declarar array
	
	//llenar array
	printf("Impresion en reversa\n");
	printf("---------------------------------\n" );
	printf("Ingrese el la cantidad de numero que desea Ingresar\n");
	
	scanf("%d",&tamano);

	int vector[tamano];


		printf("Ingresa %d numeros: \n", tamano);
		for (int i = 0; i < tamano; i++)
		{
			/* code */

			printf("Numero-%d\n", i+1);
			scanf("%d",&vector[i]);

		}

		printf("Impresion de numeros segun ingresados\n");

			for (int i = 0; i < tamano; i++)
		{
			/* code */

			printf("%d\n", vector[i]);
			

		}


printf("Numeros al reves\n");

	for (int i = tamano; i >0; i--)
		{
			/* code */

		printf("%d\n", vector[i]);

		}





	}

