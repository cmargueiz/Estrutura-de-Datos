#include <stdio.h>
 int main()
 {
 	int num,cont;

 	scanf("%d",&num);


for (int i = 1; i <= num; i++)
{
	if (num%i==0 )
	{
		cont++;
	}
}

printf("%d\n",cont);

if (cont==2)
{
	printf("Es primo\n");
}

 	return 0;
 }
