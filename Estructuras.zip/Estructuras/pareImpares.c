#include <stdio.h>


#define tamano 10

int main(void)
{
	/* code */

	int vector[10];
	printf("Ingrese 10 numeros\n");

	for (int i = 0; i < tamano;i++)
	{
		/* code */
		printf("Ingrese el valor: %d\n",i+1);
		scanf("%d",&vector[i]);
	}

printf("Numeros pares\n");


	for (int i = 0; i < tamano;i++)
	{
		/* code */
		if (vector[i]%2==0)
		{
			/* code */
			printf("%d ", vector[i]);
		}
		
	}
printf("\nNumeros impares\n");

	for (int i = 0; i < tamano; i++)
	{
		/* code */
		if (vector[i]%2!=0)
		{
			/* code */
			printf("%d ", vector[i]);
		}
		
	}


	return 0;
}
