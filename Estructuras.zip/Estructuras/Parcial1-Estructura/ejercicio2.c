#include <stdio.h>

//MATRIZ AMIGA

int	main(){
	int  temp1,temp2;
	
	
	int matriz[3][3];
	
	printf("Ingrese numeros a la matriz\n");
	
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3 ; j++)
		{
			printf("Dato de la posicion: [%d][%d]",i,j);
			scanf("%d",&matriz[i][j]);
		}
		
	}
	
	//SUMANDO FILA 1
	
	for (int i = 0; i < 3; i++)
	{
		temp1=temp1+matriz[0][i];
	}
	
	//SUMANDO FILA 2
	for (int i = 0; i <3 ; i++)
	{
		temp2=temp2+matriz[1][i];
	}
	
	//EVALUANDO FILA 1 Y FILA 2
	
	if (temp1==temp2)
	{
		temp1=0;
		temp2=0;

		
		//printf("SUMANDO FILA 3\n");
		
		for (int i = 0; i < 3; i++)
		{
			temp1=temp1+matriz[2][i];
		}
		
		//printf("SUMANDO COLUMNA 1 \n");
		
		for (int i = 0; i <3 ; i++)
		{
			temp2=temp2+matriz[i][0];
		}
		
		
		//printf("EVALUANDO FILA 3 Y COLUMNA 1 \n");
		
		if (temp1 == temp2)
		{

		temp1=0;
		temp2=0;
			//printf("SUMANDO COLUMNA 2\n");
			
			for (int i = 0; i <3 ; i++)
			{
					temp1=temp1+matriz[i][1];
			}
			
			//printf("SUMANDO COLUMNA 3 \n");
			
			for (int i = 0; i <3 ; i++)
			{
				temp2=temp2+matriz[i][2];
			}
			
			
			//"EVALUANDO COLUMNA2 Y COLUMNA 3 \n");
	
			
				if (temp1==temp2)
				{
					
		temp1=0;
		temp2=0;
		//SUMANDO DIAGONAL1
			
		for (int i = 0; i <3 ; i++)
		{
			temp1=temp1+matriz[i][i];
		}
		
		//SUMANDO DIAGONAL2
			
		for (int i = 0; i <3 ; i++)
		{
			temp2=temp2+matriz[i][i];
		}
					
					//EVALUANDO DIAGONAL 1 Y DIAGONAL 2
					
					if (temp1==temp2)
					{
						printf("ES UNA MATRIZ AMIGA\n");
					}else{
						printf("NO ES UNA MATRIZ AMIGA\n");
					}
					
					
					
				}else{
					printf("NO ES UNA MATRIZ AMIGA\n");
					
				}
				
			
			
			
			
		}else{
					printf("NO ES UNA MATRIZ AMIGA\n" );
					
				}
		
		
		
		
		
		
		
		
		
		
	}else{
		printf("NO ES UNA MATRIZ AMIGA\n" );
		
	}
	
	
	
	
	
	
	
	
	
	
	return 0;
	}
