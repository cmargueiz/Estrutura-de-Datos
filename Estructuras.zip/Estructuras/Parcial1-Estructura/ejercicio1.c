#include <stdio.h>

int main()
{
	int fila,columna,menFila,mayColumna,column;
	printf("Ingrese el numero de filas de la matriz\n");
	scanf("%d",&fila);
	printf("Ingrese el numero de columnas de la matriz\n");
	scanf("%d",&columna);

	int matriz[fila][columna];


for (int i = 0; i < fila; i++)
{
	for (int j = 0; j < columna; j++)
	{
		printf("Dato de la posicion [%d][%d] :",i,j);
		scanf("%d",&matriz[i][j]);
	}
}



for (int i = 0; i < fila; i++)
{
	for (int j = 0; j < columna; j++)
	{
		menFila=100000;
		for (int k = 0; k < columna; k++)
		{

			if (matriz[i][j]<matriz[i][k])
			{
				menFila=matriz[i][j];
				
			}
		}
		printf("%d\n",menFila );
	}
}


	return 0;
}